#include "main.h"

//DigitalOut myled(LED1);

PwmOut pwm1_led(PF_0), pwm1(PA_8);
DigitalOut enable_motor(PB_7);
DigitalIn pf1(PF_1), pa4(PA_4); // Forces PF_1 as input
// don't use PA_4 and PB_0 together
AnalogIn an_peak_detect(PB_0), an_pot_vmin(PB_1), an_pot_vmax(PA_3), an_pot_sens(PA_1);

Ticker ticker_task_inputs, ticker_task_output;

#ifdef DEBUG
Serial pc(USBTX, USBRX); // tx, rx
Ticker ticker_task_debug;
#endif

// Global variables
float motorval, peak_detect, vmin, vmax, sens;
float myGainMultiplier = 3.3f;

int main() {
    
    // Init
    pwm1_led.period_us(50);
    pwm1_led.write(0.5);
    
    pwm1.period_us(50);
    pwm1.write(0.5);

    //pwm1_n.period_us(25);
    //pwm1_n.write(0.5);

    // Pull-up config test
    //pin_mode(PB_0, PullNone);
    //GPIOB->PUPDR &= ~(GPIO_PUPDR_PUPDR0);
    //GPIOB->PUPDR = (uint32_t)0x00000000;

    ticker_task_inputs.attach_us(&task_input_update, 1000);
    ticker_task_output.attach_us(&task_output_update, 1000);

    #ifdef DEBUG
    pc.baud(115200);
    ticker_task_debug.attach(&task_debug, 0.1);
    pc.printf("BAB command");
    #endif

    peak_detect = 0;
    
    motorval = 0.0;
    sens = 0.0;
    vmin = 0.0;
    vmax = 1.0;
    
    enable_motor.write(1);

    while(1) {

        /*
        myled = 1; // LED is ON
        wait(0.2); // 200 ms
        myled = 0; // LED is OFF
        wait(1.0); // 1 sec
        */
        

        /*for(float p = 0.0f; p < 1.0f; p += 0.01f) {
            pwm1.write(p);
            wait(0.01);
        }*/

    }
}

void task_input_update (void) {
    peak_detect = an_peak_detect.read();
    vmin = an_pot_vmin.read();
        vmin = ( vmin < 0.05f ? 0.0f : vmin );
        vmin = ( vmin > 0.95f ? 1.0f : vmin );
    vmax = an_pot_vmax.read();
        vmax = ( vmax < 0.05f ? 0.0f : vmax );
        vmax = ( vmax > 0.95f ? 1.0f : vmax );
    sens = an_pot_sens.read();
        sens = ( sens < 0.05f ? 0.0f : sens );
        sens = ( sens > 0.95f ? 1.0f : sens );
    
}

void task_output_update (void) {
    // NON : Range of PwmOut is 2 * AnalogIn Range
    //vmax *= 2.0f;
    //sens *= 2.0f;
    
    motorval = peak_detect;

    // motorval -= (0.2f / myGainMultiplier);
    motorval -= 0.14f;
    motorval = ( motorval < 0.0f ? 0.0f : motorval );
    
    motorval *= (2.0f * myGainMultiplier);
    motorval += (sens * vmin);
    
    motorval = ( motorval < vmin ? vmin : motorval );
    
    if (vmin <= vmax) {
        motorval = ( motorval > vmax ? vmax : motorval );
        }
 
    if (motorval > 0.95f) {
        motorval = 0.95f;
    }
    else if (motorval < 0.03f) {
        motorval = 0.0f;
    }
    
    //motorval = 1.0f; // pour test avec moteur a fond

    pwm1_led.write(motorval);
    pwm1.write(motorval);
    //pwm1_n.write(1 - peak_detect);
}

#ifdef DEBUG
void task_debug (void) {
    pc.printf("motorval : %f\r\n", (motorval));
    pc.printf("peak_detect : %f\r\n", peak_detect);
    pc.printf("sens : %f\r\n", sens);
    pc.printf("vmin : %f\r\n", vmin);
    pc.printf("vmax : %f\r\n", vmax);
}
#endif
